<?php
define("KEY", "Lariza");
define("COD", "AES-128-ECB");


?>